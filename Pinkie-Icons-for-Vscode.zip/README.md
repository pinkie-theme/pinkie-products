# 🎀 Pinkie Icons for Vscode 🎀

*"Because your files deserve to be cute too!"*

Made with lots of love 💖 by **JustDuyen**.

---

Welcome to **Pinkie Icons for Vscode**! A super adorable, flat, and minimalist icon theme crafted specifically to match the Pinkie for Vscode color theme. 

## ✨ Super Cute Features ✨

- 📁 **Pink Folders**: Folders are adorable pastel pink file clips with tiny hearts!
- 🗂️ **Root Folders**: Workspace root folders use a bolder ruby-pink color with a white heart, making them stand out smartly from subfolders.
- 📄 **Cute Files**: Standard files are clean white documents with pink outlines and a cute dot.

## 📸 Sneak Peek

![Pinkie Icons Logo](icon.png)

## 🎀 How to Activate

1. Press `Ctrl + K` then `Ctrl + T`.
2. Select **File Icon Theme**.
3. Choose **Pinkie Icons**.
4. Yay! Your file tree is now cute! 🎉

*Enjoy coding with love & cuteness!* ✨ (´ ω `♡)
